#ifndef GETSPRITES_H
#define GETSPRITES_H
#include <QPixmap>

class getSprites
{
public:
    getSprites();
    QPixmap *getZero();
    QPixmap *getGWing();
    QPixmap *getGWing2();
    QPixmap *getZaku();

};

#endif // GETSPRITES_H
