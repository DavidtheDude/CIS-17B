#include "animation.h"

Animation::Animation()
{
}
