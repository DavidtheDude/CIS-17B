#include "getsprites.h"

getSprites::getSprites()
{
}

QPixmap *getSprites::getZero()
{
    QPixmap *zero = new QPixmap;
    zero="qrc:/zeroModified.png";

}

QPixmap *getSprites::getGWing()
{

}

QPixmap *getSprites::getGWing2()
{

}

QPixmap *getSprites::getZaku()
{

}
